package com.wiprotest.natarajan.demo.exception;

public class BatchIDNotFoundException extends RuntimeException
{
	  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private int errorCode;
	private String message;
	

	protected BatchIDNotFoundException() {}

	public BatchIDNotFoundException(int errorCode, String message) 
	{
		this.errorCode=errorCode;
	    this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
}
