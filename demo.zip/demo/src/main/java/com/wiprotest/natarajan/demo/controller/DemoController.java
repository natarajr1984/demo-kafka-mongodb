package com.wiprotest.natarajan.demo.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.apache.commons.lang3.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.wiprotest.natarajan.demo.domain.DemoInfo;
import com.wiprotest.natarajan.demo.domain.ResponseMessage;
import com.wiprotest.natarajan.demo.exception.UniqueDataRequiredException;
import com.wiprotest.natarajan.demo.exception.BatchIDNotFoundException;
import com.wiprotest.natarajan.demo.exception.InvalidDataException;
import com.wiprotest.natarajan.demo.kafka.producer.service.KafkaProducerService;
import com.wiprotest.natarajan.demo.service.api.DemoServiceApi;

@RestController
public class DemoController 
{
	Logger logger =LoggerFactory.getLogger(DemoController.class);
	
	@Autowired
	DemoServiceApi demoServiceApi;
	
	@Autowired
	KafkaProducerService kafkaProducerService;

	@PostMapping("/saveDemo")
	public ResponseEntity<ResponseMessage> saveDemo(@RequestBody DemoInfo demoInfoRequest)
	{
		ResponseEntity<ResponseMessage> responseEntity=null;
		ResponseMessage responseMessage=new ResponseMessage();
		String name=demoInfoRequest.getName();
		Integer count =demoInfoRequest.getCount();
		Integer requestId = demoInfoRequest.getRequestId();
		Integer year =demoInfoRequest.getYear();
		if(null!=name && null!=count && null!=requestId && (null!=year && year!=0))
		{
			// checking duplicate request id
			boolean isDuplicateRequestID =demoServiceApi.isUniqueRequestID(demoInfoRequest.getRequestId());
			if(isDuplicateRequestID)
			{
			    throw new UniqueDataRequiredException(111,"Request ID should be unique");
			}
			else
			{
				if(demoInfoRequest.getCount()>0)
				{
					String totalSize=String.valueOf(demoInfoRequest.getCount());
					
					if(demoInfoRequest.getCount()>0 && totalSize.length()<=3)
					{
						String batchId = RandomStringUtils.randomAlphanumeric(10); // generating random unique number
						demoInfoRequest.setBatchId(batchId);
						
						List<DemoInfo> demoInfos=demoServiceApi.SaveData(demoInfoRequest); // save the data 
						if(null!=demoInfos && demoInfos.size()>0 )
						{
							responseMessage.setStatus("Success");
							responseMessage.setErrorCode(HttpStatus.OK.value());
							responseMessage.setBatchId(demoInfoRequest.getBatchId());
							responseEntity=ResponseEntity.accepted().body(responseMessage);
							
							demoInfos.forEach(demoInfoObj->
							{
								demoInfoObj.setDayOfTheWeek(new SimpleDateFormat("EEEE", Locale.ENGLISH).format(new Date().getTime()));
								demoInfoObj.setTimeStamp(new Date());
								
								// sending messages to kafka
								kafkaProducerService.sendMessage(demoInfoObj);
							});
						}
						else
						{
							responseMessage.setStatus("Failed");
							responseMessage.setErrorCode(112);
							responseMessage.setDescription("Failed to store");
							responseEntity=ResponseEntity.badRequest().body(responseMessage);
						}
					}
					else
					{
						throw new InvalidDataException(112,"Invalid Count, it should be 0 to 999");
					}
				}
				else
				{
					throw new InvalidDataException(113,"Count cannot be less than or equal to 0");
				}
			}
		}
		else
		{
			throw new UniqueDataRequiredException(114,"one or more parameter is null");
		}
		return responseEntity;
	}
	
	@GetMapping("/getDemoData/{batchId}")
	public ResponseEntity<?> getDemoDetails(@PathVariable String batchId)
	{
		ResponseEntity<?> responseEntity=null;
		
		List<DemoInfo> demoInfos =demoServiceApi.getDemoDataByBatchID(batchId);
		if(null!=demoInfos && demoInfos.size()>0)
		{
			responseEntity=ResponseEntity.accepted().body(demoInfos);
		}
		else
		{
			throw new BatchIDNotFoundException(404, "Requested Batch ID "+batchId+" not found");
		}
		return responseEntity;
	}
}
