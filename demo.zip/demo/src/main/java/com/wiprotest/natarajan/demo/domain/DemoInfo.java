package com.wiprotest.natarajan.demo.domain;

import java.io.Serializable;
import java.util.Date;

import io.swagger.annotations.ApiModelProperty;

public class DemoInfo implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@ApiModelProperty(notes = "Auto generated unique ID by mongo")
	private String mongoId;
	
	@ApiModelProperty(notes = "Auto generated unique ID")
	private String batchId;
	
	@ApiModelProperty(notes = "Name of the Demo", required = true)
	private String name;

	@ApiModelProperty(notes = "Year of the Demo", required = true)
    private Integer year;

	@ApiModelProperty(notes = "No. of demos", required = true)
    private Integer count;

	@ApiModelProperty(notes = "Unique request ID", required = true)
    private Integer requestId;
    
	@ApiModelProperty(notes = "day of the week value sent to kafka")
    private String dayOfTheWeek;
	
	@ApiModelProperty(notes = "Timestamp sent to kafka") 
    private Date timeStamp;
    
	public String getBatchId()
	{
		return batchId;
	}

	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getYear() {
		return year;
	}

	public void setYear(Integer year) {
		this.year = year;
	}

	public Integer getCount() {
		return count;
	}

	public void setCount(Integer count) {
		this.count = count;
	}

	public Integer getRequestId() {
		return requestId;
	}

	public void setRequestId(Integer requestId) {
		this.requestId = requestId;
	}

	public String getMongoId() {
		return mongoId;
	}

	public void setMongoId(String mongoId) {
		this.mongoId = mongoId;
	}

	public String getDayOfTheWeek() {
		return dayOfTheWeek;
	}

	public void setDayOfTheWeek(String dayOfTheWeek) {
		this.dayOfTheWeek = dayOfTheWeek;
	}

	public Date getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(Date timeStamp) {
		this.timeStamp = timeStamp;
	}
}
