package com.wiprotest.natarajan.demo.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import com.wiprotest.natarajan.demo.dao.api.DemoDaoServiceApi;
import com.wiprotest.natarajan.demo.entity.DemoEntity;
import com.wiprotest.natarajan.demo.repository.DemoMongoRepository;


@Service
public class DemoDaoServiceImpl implements DemoDaoServiceApi
{
	
	@Autowired
	private DemoMongoRepository demoMongoRepository;
	
	@Autowired
	MongoTemplate mongoTemplate;

	@Override
	public List<DemoEntity> saveData(DemoEntity demoEntity) 
	{
		// TODO Auto-generated method stub
		List<DemoEntity> demoEntities=new ArrayList<DemoEntity>();
		for(int i=0;i<demoEntity.getCount();i++)
		{
			demoEntities.add(demoEntity);
		}
		//DemoEntity deEntity=demoMongoRepository.save(demoEntity);
		demoEntities=demoMongoRepository.saveAll(demoEntities);
		return demoEntities;
	}

}
