package com.wiprotest.natarajan.demo.exception.interceptor;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

import com.wiprotest.natarajan.demo.exception.UniqueDataRequiredException;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import com.wiprotest.natarajan.demo.exception.BatchIDNotFoundException;
import com.wiprotest.natarajan.demo.exception.ErrorResponse;
import com.wiprotest.natarajan.demo.exception.InvalidDataException;

@ControllerAdvice
public class CustomExceptionInterceptor 
{
	@ExceptionHandler(UniqueDataRequiredException.class)
    public final ResponseEntity<Object> handleAllExceptions(UniqueDataRequiredException ex, WebRequest request) 
	{
        ErrorResponse error = new ErrorResponse(ex.getErrorCode(),ex.getLocalizedMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
        return new ResponseEntity<Object>(error, HttpStatus.INTERNAL_SERVER_ERROR);
    }
	
	@ExceptionHandler(InvalidDataException.class)
    public final ResponseEntity<Object> handleAllExceptions(InvalidDataException ex, WebRequest request) 
	{
		ErrorResponse error = new ErrorResponse(ex.getErrorCode(),ex.getLocalizedMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
        return new ResponseEntity<Object>(error, HttpStatus.INTERNAL_SERVER_ERROR);
    }
	
	@ExceptionHandler(HttpMessageNotReadableException.class)
	public final ResponseEntity<Object> handleAllExceptions(HttpMessageNotReadableException ex, WebRequest request) 
	{
		 ErrorResponse error = new ErrorResponse(HttpStatus.BAD_REQUEST.value(),ex.getMessage(),HttpStatus.BAD_REQUEST);
	     return new ResponseEntity<Object>(error, HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(BatchIDNotFoundException.class)
	public final ResponseEntity<Object> handleAllExceptions(BatchIDNotFoundException ex, WebRequest request) 
	{
		 ErrorResponse error = new ErrorResponse(HttpStatus.NOT_FOUND.value(),ex.getMessage(),HttpStatus.NOT_FOUND);
	     return new ResponseEntity<Object>(error, HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(InvalidFormatException.class)
	public final ResponseEntity<Object> handleAllExceptions(InvalidFormatException ex, WebRequest request) 
	{
		 ErrorResponse error = new ErrorResponse(HttpStatus.BAD_REQUEST.value(),ex.getMessage(),HttpStatus.BAD_REQUEST);
	     return new ResponseEntity<Object>(error, HttpStatus.BAD_REQUEST);
	}
	
	
	
	
	
}
