package com.wiprotest.natarajan.demo.kafka.consumer.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wiprotest.natarajan.demo.domain.DemoInfo;

@Service
public final class KafkaConsumerService 
{
	Logger logger =LoggerFactory.getLogger(KafkaConsumerService.class);
	
	@KafkaListener(topics = "demo", groupId = "demo-group")
	public void consume(DemoInfo message) 
	{
		ObjectMapper Obj = new ObjectMapper();
		try 
		{
			message.setDayOfTheWeek(new SimpleDateFormat("EEEE", Locale.ENGLISH).format(new Date().getTime()));
			message.setTimeStamp(new Date());
			logger.info("Received Messasge in group - demo-group: "+ Obj.writeValueAsString(message) );
		} 
		catch (JsonProcessingException e)
		{
			// TODO Auto-generated catch block
			logger.error("Parsing Error", e);
		}
	}
}
