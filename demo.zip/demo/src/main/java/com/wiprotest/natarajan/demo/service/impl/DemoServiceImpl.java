package com.wiprotest.natarajan.demo.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wiprotest.natarajan.demo.dao.api.DemoDaoServiceApi;
import com.wiprotest.natarajan.demo.domain.DemoInfo;
import com.wiprotest.natarajan.demo.entity.DemoEntity;
import com.wiprotest.natarajan.demo.repository.DemoMongoRepository;
import com.wiprotest.natarajan.demo.service.api.DemoServiceApi;


@Service
public class DemoServiceImpl implements DemoServiceApi
{

	@Autowired
	DemoDaoServiceApi demoDaoServiceApi;
	
	@Autowired
	DemoMongoRepository demoRepo;
	
	
	ModelMapper modelMapper=new ModelMapper();

	@Override
	public List<DemoInfo> SaveData(DemoInfo demoInfo) 
	{
		// TODO Auto-generated method stub
		
		 DemoEntity demoEntity= modelMapper.map(demoInfo, DemoEntity.class);
		
		 List<DemoEntity> demoEntities=demoDaoServiceApi.saveData(demoEntity);
		 
		 List<DemoInfo> demoInfos = demoEntities.stream()
	                							.map(p -> modelMapper.map(p, DemoInfo.class))
	                							.collect(Collectors.toList());
		 return demoInfos;
	}
	
	public boolean isUniqueRequestID(Integer requestId)
	{
		boolean requestIdPresent=false;
		List<DemoEntity> demoEntities=demoRepo.getByRequestId(requestId);
		if(null!=demoEntities & demoEntities.size()>0)
		{
			requestIdPresent=true;
		}
		return requestIdPresent;
	}
	
	public List<DemoInfo> getDemoDataByBatchID(String batchId)
	{
		List<DemoEntity> demoEntities=demoRepo.findAllByBatchId(batchId);
		
		List<DemoInfo> demoInfos = demoEntities.stream()
												.map(p -> modelMapper.map(p, DemoInfo.class))
												.collect(Collectors.toList());
		 return demoInfos;
		
	}
}
