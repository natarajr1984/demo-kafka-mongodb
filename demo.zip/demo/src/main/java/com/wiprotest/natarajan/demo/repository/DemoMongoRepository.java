package com.wiprotest.natarajan.demo.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.wiprotest.natarajan.demo.entity.DemoEntity;

public interface DemoMongoRepository extends MongoRepository<DemoEntity, String>
{
	public List<DemoEntity> getByRequestId(Integer requestId);
	
	public List<DemoEntity> findAllByBatchId(String batchId);
	
}
