package com.wiprotest.natarajan.demo.exception;


import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.http.HttpStatus;

@XmlRootElement(name = "error")
public class ErrorResponse
{
	public ErrorResponse(int errorCode,String message,HttpStatus status) 
	{
        super();
        this.errorCode = errorCode;
        this.message = message;
        this.status=status;
    }
 
    //General error message about nature of error
    private String message;
 
    //Specific errors in API request processing
    private int errorCode;
    
    private HttpStatus status;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	public HttpStatus getStatus() {
		return status;
	}

	public void setStatus(HttpStatus status) {
		this.status = status;
	}
}
