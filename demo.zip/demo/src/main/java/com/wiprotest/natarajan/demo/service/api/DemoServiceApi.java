package com.wiprotest.natarajan.demo.service.api;

import java.util.List;

import org.springframework.stereotype.Service;

import com.wiprotest.natarajan.demo.domain.DemoInfo;

@Service
public interface DemoServiceApi 
{
	List<DemoInfo> SaveData(DemoInfo demoInfo);
	
	boolean isUniqueRequestID(Integer requestId);
	
	List<DemoInfo> getDemoDataByBatchID(String batchId);
}
