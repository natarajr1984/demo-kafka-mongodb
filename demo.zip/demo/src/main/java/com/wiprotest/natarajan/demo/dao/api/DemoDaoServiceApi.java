package com.wiprotest.natarajan.demo.dao.api;

import java.util.List;

import org.springframework.stereotype.Service;

import com.wiprotest.natarajan.demo.entity.DemoEntity;

@Service
public interface DemoDaoServiceApi 
{
	List<DemoEntity> saveData(DemoEntity demoEntity);
	
}
