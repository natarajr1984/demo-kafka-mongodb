package com.wiprotest.natarajan.demo.kafka.producer.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wiprotest.natarajan.demo.domain.DemoInfo;

@Service
public final class KafkaProducerService 
{
	Logger logger=LoggerFactory.getLogger(KafkaProducerService.class);
	
	private final KafkaTemplate<String, DemoInfo> kafkaTemplate;
	
	private final String TOPIC = "demo";

	public KafkaProducerService(KafkaTemplate<String, DemoInfo> kafkaTemplate) 
	{
		this.kafkaTemplate = kafkaTemplate;
	}

	public void sendMessage(DemoInfo message)
	{
		//kafkaTemplate.send(TOPIC, message);
		
		ListenableFuture<SendResult<String, DemoInfo>> callBack = kafkaTemplate.send(TOPIC, null, message);
		callBack.addCallback(new ListenableFutureCallback<SendResult<String, DemoInfo>>() 
		{
		    @Override
		    public void onFailure(Throwable ex) 
		    {
		    	logger.error("unable to send message= " + message, ex);
		    }

			@Override
			public void onSuccess(SendResult<String, DemoInfo> result) 
			{
				// TODO Auto-generated method stub
				try 
				{
					logger.info("sent message= " + new ObjectMapper().writeValueAsString(message) + " with offset= " + result.getRecordMetadata().offset());
				} 
				catch (JsonProcessingException e) 
				{
					// TODO Auto-generated catch block
					logger.error("Object Conversion error : ", e);
				}
			}
		});
	}
}
